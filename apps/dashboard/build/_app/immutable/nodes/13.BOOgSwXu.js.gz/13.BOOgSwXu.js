import{fB as f}from"../chunks/CFnBgO4x.js";export{f as component};
